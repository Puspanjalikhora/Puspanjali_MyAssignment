package Assignment5;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import dev.failsafe.internal.util.Assert;

public class Task2 {

	public static void main(String[] args) throws InterruptedException {
	WebDriver driver= new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		Boolean allLink=driver.findElement(By.xpath("//img[contains(@alt,'logo')]")).isDisplayed();
		Assert.isTrue(true, "logo is present", allLink);
		System.out.println("logo is present");
		driver.close();
		
	

	}
}


