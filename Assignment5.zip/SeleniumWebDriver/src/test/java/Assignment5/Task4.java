package Assignment5;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task4 {

	public static void main(String[] args) throws InterruptedException 
	{
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		Thread.sleep(2000);
		driver.manage().window().maximize();
		
		//to perform Scroll on application using Selenium
	      JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("window.scrollBy(0,550)");
				
	   List<WebElement> allLinks=driver.findElements(By.xpath("//div/a[@href]"));
	
	  for(WebElement ele:allLinks)
	    {
		
		  String text=ele.getAttribute("href");
		  System.out.println("all href values from social media icons are :"+text);
		  
	    }

	  Map<String,String> mp1= new LinkedHashMap<String, String>();
       mp1.put("FaceBook", "fburl");
       mp1.put("Twitter","Twitter url");
       mp1.put("Youtube", "Youtube UR");
       mp1.put("Linkedin", "Linkedin URL");
       System.out.println();
       System.out.println("4 href values in map are:"+ mp1);  

	}
				

	}


