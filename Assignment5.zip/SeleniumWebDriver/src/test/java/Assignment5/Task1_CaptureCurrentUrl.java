package Assignment5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1_CaptureCurrentUrl {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
	String url	=driver.getCurrentUrl();
		
	if(url.endsWith("login"))
	
	{
		System.out.println("Able to find out the Url:"+ url);
	}
	
	else
	{
		System.out.println("Able to find out the Url:"+ url);
	}
	
	driver.close();
	}

}
