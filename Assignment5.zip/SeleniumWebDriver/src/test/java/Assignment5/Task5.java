package Assignment5;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task5 {

	public static void main(String[] args) throws InterruptedException
	
      {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		//to perform Scroll on application using Selenium
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,550)");
			
	List<WebElement > allLinks	=driver.findElements(By.xpath("//a[@href]"));
	
	  for(WebElement ele:allLinks)
	    {
		
		  String text=ele.getAttribute("href");
		  System.out.println("all href values from social media icons are :"+text);
		  
		  if(text.contains("youtube"))
	    	{
	    		
	    	   // ele.click();
			  System.out.println("Validation is working correct now we can able to find  youtube");
	    	    break;
	         }
        //driver.close();
	}
	  
	}

}
