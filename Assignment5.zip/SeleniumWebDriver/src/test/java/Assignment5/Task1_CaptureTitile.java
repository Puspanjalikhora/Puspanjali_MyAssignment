package Assignment5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1_CaptureTitile {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
	 String title=driver.getTitle();
		
	if(title.contains("HRM"))
	{
	
		System.out.println("The Application Titile is :"+title);
	}
	else
	{
		System.out.println("unable to find");
	}
	
	
	}
	
}
