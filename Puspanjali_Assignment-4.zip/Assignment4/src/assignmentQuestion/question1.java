package assignmentQuestion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

//Create a list of String and print the values in reverse order
//Input – Java, Selenium, TestNG, Git, Github
//Output- Github, Git, TestNG, Selenium, Java

public class question1
{

	public static void main(String[] args) 
	{
		
		
		//Converting Array to List
		List<String> number = new ArrayList<>(Arrays.asList("Java","Selenium","TestNG","Git","Github"));
	       
		   System.out.println("list of String are:Java, Selenium, TestNG, Git, Github");
	        System.out.println( "Reverse order of given List :");
	 
	    
	        Collections.reverse(number);
	       
	        System.out.println(number);
	
	}

}
