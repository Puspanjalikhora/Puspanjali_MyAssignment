package assignmentQuestion;
//Write a program that will remove duplicate values from List
//Input – Java, TestNG, Maven, Java, 
//Output – Java, TestNG, Maven

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class question3 
{

	public static void main(String[] args) 
	{
		
		        //First Ways
		
		       // converting  a arraylist into a new list
				List<String> originalList = new ArrayList<>();
				originalList.add("Java");
				originalList.add("TestNG");
				originalList.add("Maven");
				originalList.add("Java");
				

				System.out.println("Original list values : " + originalList);

				// Creating linkedhashset object
				Set<String> obj = new LinkedHashSet<>();

				// adding list values to set
				obj.addAll(originalList);

				// removing all values from list
				originalList.clear();

				// add all values from set to list.
				originalList.addAll(obj);

				// printing the cleaned list without duplicates
				System.out.println("originalList values ater removing duplicates  : " + originalList);

			}
		
		
		//2nd ways
	
		//Set is used for element duplicate value 
		/*ArrayList<String> obj1=new ArrayList<String>(); 
		Set<String> list = new HashSet<>();
		
		obj1.add("Java");
		obj1.add("TestNG");
		obj1.add("Maven");
		obj1.add("Java");
		System.out.println("The given string are:"+obj1);
		System.out.println(list.addAll(obj1));
		
		System.out.println(list);*/
		

	}

	

