package assignmentQuestion;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//Create a list of values and print the second element, second last element.
//Input – 10,45, 90,45, 23, 90, 44
//Output – 45,90

public class question4
{

	public static void main(String[] args) 
	{
		//First way
		
		 List<Integer> list=new ArrayList<Integer>(); 
		 
		    list.add(10);
			list.add(45);
			list.add(90);
			list.add(23);
			list.add(90);
			list.add(44);
		
		
		for(int element : list)
        {
			
			
           
		     System.out.println("List of interger values are :"+element);
	   }
		
        
		System.out.println("");
			
			System.out.println("first way output is :"+list.get(1)); 
			System.out.println("First way output is :"+list.get(4));
		
		
		//2nd ways 
		
		
		List<Integer> list1=new ArrayList<Integer>(); 
		Set<Integer> a = new HashSet<>();
		 
	    list1 .add(10);
		list1.add(45);
		list1.add(90);
		list1.add(23);
		list1.add(90);
		list1.add(44);
        
        for(Integer element :list )
        {
        	
        	if(element==45)
        	{
        		a.add(element);
        	}
        	else if(element==90)
        	{
        		a.add(element);
        	}
          
        }
        for (int element : a)
        {
            System.out.println("2nd way Out put is:"+element);
        }
		
					
				
	}		
	     

}
