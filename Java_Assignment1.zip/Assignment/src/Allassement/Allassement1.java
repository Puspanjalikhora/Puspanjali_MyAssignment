package Allassement;

public class Allassement1 
{
	//Write a program to swap two number. For example a=10 and b=20 output should be a=20 and b=10
  public static void main(String[] args) 
  {
	  int a=10, b=20;      
	  System.out.println("Before swap the number of a is:" + a);
	  System.out.println("Before swap the number of b is:" + b);
	  System.out.println();
	  a=a+b;//a=30 (10+20)    
	  b=a-b;//b=10 (30-20)    
	  a=a-b;//a=20 (30-10)
	  System.out.println("After swap the number of a is:" + a);
	  System.out.println("Afer swap the number of b is:" + b);
	  System.out.println();
	  System.out.println("Final out put of a:"+a);
	  System.out.println("Final out put of b:"+b);
	  
	    
	  }  
  }

