package Allassement;
//Task 9- Write a program which will break the current execution if it find number 85
//Input – [12,34,66,85,900]

public class Allassement9 
{
  public static void main(String[] args)
  {
	  //First way 
	  
	  /*int[] num=new int[5];
	  num[0]=12;
	  num[1]=34;
	  num[2]=66;
	  num[3]=85;
	  num[4]=900;
	 for (int i=0;i<5;i++)
	 {
		 if(num[3]==num[i])
		 {
			 System.out.println(num[i]);
		 }
			 
	 }*/
	  
	  //2nd way to find the value using foreach loop
	  int[] number= {12,34,66,85,900};
	  
	  int No=85;
	  for( int var:number)
	  {
		  if(No==var)
		  {
		  System.out.println("it is find the number 85 and break the current execution:"+var);
			  
	  }
	  
	  }
  }
}
