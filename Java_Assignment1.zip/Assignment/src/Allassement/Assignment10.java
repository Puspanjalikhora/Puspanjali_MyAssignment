
//Write a program which will break the current execution if it find “Selenium”
//Input – [“Java”,”JavaScript”,”Selenium”,”Python”,”Mukesh”

package Allassement;

public class Assignment10 
{
	public static void main(String[] args)
	  {
		//using for loop to find the value 
		
		 /*   String[] names= {"Java","JavaScript","Selenium","Python","Mukesh"};
		    String name="Selenium";
		    
		    for(int i=0;i<names.length;i++)
		         {
		    	
		        if (names[i]==name)
		        {
		        	
		        
		        System.out.println(names[i]);
		    }*/
		   
		//2nd ways using for each loop find the value 
		
		String[] names= {"Java","JavaScript","Selenium","Python","Mukesh"};
		String Course="Selenium";
		for(String Courses: names)
		{
			if(Course==Courses)
		
			{
				System.out.println("it is find the Selenium and break the current execution: "+Courses);
			}
	       }  
	  }
}
