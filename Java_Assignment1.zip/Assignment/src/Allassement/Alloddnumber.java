package Allassement;
//Task 5- Write a program to print all odd numbers from 1-50
public class Alloddnumber 
{
	public static void main(String[] args) 
	
	{
		int num=50;
		
		for(int i=1;i<num;i++)
		{
          if(i%2!=0)
          {
        	  System.out.println(i);
          }
		
		
		}
		
	}
	
	

}
