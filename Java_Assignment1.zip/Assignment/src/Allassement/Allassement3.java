package Allassement;
//Task 3-  Write a program to print the average of below 5 numbers.
//10,90.78,111,8989,7876

public class Allassement3
{
	public static void main(String args[])
	{ 
		int a=10;
		int b=111;
		int c=8989;
		int d= 7876;
		int x1=a+b+c+d;
		double e=90.78d;
		double sum=x1+e;
		double Avg= (sum/5);
		
		System.out.println(Avg);
    }
}
