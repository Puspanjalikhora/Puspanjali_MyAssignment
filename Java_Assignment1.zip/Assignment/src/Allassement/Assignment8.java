

//
//Task 8- Write a program to print below students marks who have scored above 80
//	Example- 78,12,89,55,35
//	Output-  78,89

package Allassement;

public class Assignment8 
{
	  public static void main(String[]args )
	   {
		 int marks =78;
		   switch(marks)
		   { 
		     case 12:
		    	 System.out.println(12);
		     break;
		     
		     case 35:
		    	 System.out.println(35);
		    	 break;
		     case 55:
		    	 System.out.println(55);
		    	 break;
		     case 78:
		    	 System.out.println(78);
		    	 //break;
		     case 89:
		    	 System.out.println(89);
		    	 break;
		    	 default:
		    		 System.out.println("print above  number"); 
		    	 
		    	 
		   
		   }

	   }
}
