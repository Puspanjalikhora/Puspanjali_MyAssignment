package Allassement;
// Write a program to print all even numbers from 1-200
public class Allevennumber 
{

	public static void main(String[] args)
	{
		int number=200;
		System.out.println("List of even numbers from 1 to "+number+": "); 
		for(int i=1;i<number;i++)
		{
			//logic to check if the number is even or not  
			//if i%2 is equal to zero, the number is even  
			
			if(i %2==0 ) 
			{
				System.out.println("Even number:" + i);
			}
			
		}
		
		
 }
}
