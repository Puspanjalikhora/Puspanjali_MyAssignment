package Allassement;

public class Assignment2
{
	//Task 2-  Write a program to print the sum of below 5 numbers.
	public static void main(String args[])
	{ 
		int a=10;
		int b=111;
		int c= a+b;
		int d=8989;
		int e= 7876;
		int f=d+e;
		int x1=c+f;
		double g=90.78d;
		double h= x1+g;
		
		System.out.println(h);
				
	} 
}
