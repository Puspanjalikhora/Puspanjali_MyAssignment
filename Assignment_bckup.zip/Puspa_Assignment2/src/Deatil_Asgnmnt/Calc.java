package Deatil_Asgnmnt;

public class Calc

{
	String name,department,email;
	int id; 
	
	public void Trainer1(String name,String dept  ,String gamil, int Trainer_id)
	{
		
		System.out.println(" Trainer1 details information :"+name+","+dept+","+gamil+","+Trainer_id);
	}
	public void Trainer2(String name,String dept  ,String gamil, int Trainer_id)
	{
     System.out.println("Trainer2 details:"+name+","+" "+dept+","+gamil+","+Trainer_id);
	}
}
