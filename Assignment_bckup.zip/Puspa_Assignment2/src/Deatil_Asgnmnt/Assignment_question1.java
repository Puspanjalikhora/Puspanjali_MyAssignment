package Deatil_Asgnmnt;

public class Assignment_question1 
{
	
	//Task1 Using method and Constructor 
	String name,department,email;
	int id; 

	public static void main(String[] args) 
	{
	

	
	
	Assignment_question1 obj= new Assignment_question1("mukesh","Testing","Mukesh@gmail.com",1);
	
	Assignment_question1 obj2= new Assignment_question1(2,"Hitesh","Testing","Mukesh@gmail.com");
	
	Assignment_question1 obj3= new Assignment_question1("Mukesh",3,"Testing","Mukesh@gmail.com");
	
	System.out.println();
	
	obj.Trainer1("mukesh","Testing","Mukesh@gmail.com",1);
	obj.Trainer2("Hitesh","Dev","Mukesh@gmail.com",2);
	obj.Trainer3("Mukesh","DevOps","Mukesh@gmail.com",3);
	
}

   public Assignment_question1(String T_name,String T_dept, String T_gmail,int T_id)
    {
	name=T_name;
	department=T_dept;
	email=T_gmail;
	id=T_id;
	 System.out.println("Trainer1 can teach : selenium");
  }
public Assignment_question1(int T_id,String T_name,String T_dept, String T_gmail)
{
	name=T_name;
	department=T_dept;
	email=T_gmail;
	id=T_id;
	 System.out.println("Trainer2 can teach : web development");
}
public Assignment_question1(String T_name,int T_id,String T_dept, String T_gmail)
{
	name=T_name;
	department=T_dept;
	email=T_gmail;
	id=T_id;
	 System.out.println("Trainer3 can teach : DevOps");
}
	

	public void Trainer3(String name,String dept  ,String gamil, int Trainer_id)
	{
		
		System.out.println("Trainer3 details  :"+name+","+dept+","+gamil+","+Trainer_id);
		
	}
	
	public void Trainer1(String name,String dept  ,String gamil, int Trainer_id)
	{
		
		System.out.println(" Trainer1 details :"+name+","+dept+","+gamil+","+Trainer_id);
		
	}
	public void Trainer2(String name,String dept  ,String gamil, int Trainer_id)
	{
     System.out.println("Trainer2 details:"+name+","+" "+dept+","+gamil+","+Trainer_id);

	}

}
