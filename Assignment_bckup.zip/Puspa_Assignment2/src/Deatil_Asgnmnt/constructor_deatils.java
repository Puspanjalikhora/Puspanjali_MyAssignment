package Deatil_Asgnmnt;



public class constructor_deatils 
{
	
	//using Constructor
	String name,department,email;
	int id;

	public static void main(String[] args)
	
	{
		constructor_deatils obj= new constructor_deatils("mukesh","Testing","Mukesh@gmail.com",1);
		
		constructor_deatils obj2= new constructor_deatils(2,"Hitesh","Testing","Mukesh@gmail.com");
		
		constructor_deatils obj3= new constructor_deatils("Mukesh",3,"Testing","Mukesh@gmail.com");
	
		
	}
	
	public constructor_deatils(String T_name,String T_dept, String T_gmail,int T_id)
	{
		name=T_name;
		department=T_dept;
		email=T_gmail;
		id=T_id;
		 System.out.println("Trainer1 can teach : selenium");
	}
	public constructor_deatils(int T_id,String T_name,String T_dept, String T_gmail)
	{
		name=T_name;
		department=T_dept;
		email=T_gmail;
		id=T_id;
		 System.out.println("Trainer2 can teach : web development");
	}
	public constructor_deatils(String T_name,int T_id,String T_dept, String T_gmail)
	{
		name=T_name;
		department=T_dept;
		email=T_gmail;
		id=T_id;
		 System.out.println("Trainer3 can teach : DevOps");
	}

	
	}



		

	


