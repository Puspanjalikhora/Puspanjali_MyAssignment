package Deatil_Asgnmnt;

import java.util.Scanner;

public class question3 {
	
	 
	public static void main(String[] args)   
	{  
	
		
		//creating an object of the Scanner class  
		Scanner sc = new Scanner(System.in); 
		System.out.println("please enter the number of student ");
		
		while(sc.hasNextLine())  
		{  
		//takes the string input and prints the same string  
		
		
		System.out.println(sc.nextLine());
		
		System.out.println("please enter  your name ");
		System.out.println(sc.nextLine());
	
		
		System.out.println("please enter your phnumber "); 
		System.out.println(sc.nextLine());  

		
		System.out.println("please enter your email "); 
		System.out.println(sc.nextLine());

		
		System.out.println("please enter your Address "); 
		System.out.println(sc.nextLine()); 
		
		System.out.println("please enter your status "); 
		System.out.println(sc.nextLine());  
	
	
	} 
		sc.close();
	} 
}


