package Deatil_Asgnmnt;

public class Triner_Class extends Trainer

{
	//using methods 
	String name,department,email;
	int id;
	

	public static void main(String[] args)
	
	{
		Triner_Class Tr= new Triner_Class();
		Tr.Trainer1("Mukesh", "Testing","mukesh@gmail.com" , 1);
		System.out.println();
		Tr.Trainer2("Hitesh", "web development", "mukesh@gmail.com", 2);
		System.out.println();
		Tr.Trainer3("Mukesh","DevOps","mukesh@gmail.com",3);
		

	}
	
	
	
	public void Trainer3(String name,String dept  ,String gamil, int Trainer_id)
	{
		
		System.out.println("Trainer3 details information :"+name+","+dept+","+gamil+","+Trainer_id);
		System.out.println("Trainer3 Can teach Devops");
	}
		
	
	}



