package Deatil_Asgnmnt;

public class assignment_Question1 
{
	
	//Task1 Using method and Constructor 
	String name,department,email;
	int id; 

	public static void main(String[] args) 
	{
	

	
	
	assignment_Question1 obj= new assignment_Question1("mukesh","Testing","Mukesh@gmail.com",1);
	
	assignment_Question1 obj2= new assignment_Question1(2,"Hitesh","Testing","Mukesh@gmail.com");
	
	assignment_Question1 obj3= new assignment_Question1("Mukesh",3,"Testing","Mukesh@gmail.com");
	
	System.out.println();
	
	obj.Trainer1("mukesh","Testing","Mukesh@gmail.com",1);
	obj.Trainer2("Hitesh","Dev","Mukesh@gmail.com",2);
	obj.Trainer3("Mukesh","DevOps","Mukesh@gmail.com",3);
	
}

   public assignment_Question1(String t_Name,String t_Dept, String t_gmail,int t_Id)
    {
	name=t_Name;
	department=t_Dept;
	email=t_gmail;
	id=t_Id;
	 System.out.println("Trainer1 can teach : selenium");
  }
public assignment_Question1(int t_Id,String t_Name,String t_Dept, String t_gmail)
{
	name=t_Name;
	department=t_Dept;
	email=t_gmail;
	id=t_Id;
	 System.out.println("Trainer2 can teach : web development");
}
public assignment_Question1(String t_Name,int t_Id,String t_Dept, String t_gmail)
{
	name=t_Name;
	department=t_Dept;
	email=t_gmail;
	id=t_Id;
	 System.out.println("Trainer3 can teach : DevOps");
}
	

	public void Trainer3(String t_Name,String t_Dept, String t_gmail,int t_Id)
	{
		
		System.out.println("Trainer3 details  :"+name+","+t_Dept+","+t_gmail+","+t_Id);
		
	}
	
	public void Trainer1(String name,String dept  ,String gamil, int trainer_Id)
	{
		
		System.out.println(" Trainer1 details :"+name+","+dept+","+gamil+","+trainer_Id);
		
	}
	public void Trainer2(String name,String dept  ,String gamil, int trainer_id)
	{
     System.out.println("Trainer2 details:"+name+","+" "+dept+","+gamil+","+trainer_id);

	}

}
