package Deatil_Asgnmnt;
//Task 2- Extension of task 1 – Store all trainer information in Array.


public class loan extends calc
 {
	 String[] Course= {"Selenium","Web Development","DevOps"};
	 String T1="Selenium";
	 String T2="Web Development";
	 String T3=" DevOps";

	public static void main(String[] args)
	{
		loan obj= new loan();
		obj.trainer1("Mukesh", "Testing","mukesh@gmail.com" , 1);
		obj.trainer2("Hitesh", "web development", "mukesh@gmail.com", 2);
		obj.Trainer3("sheker","DevOps","mukesh@gmail.com",3);
	
	}
	
	public void Trainer3(String name,String dept  ,String gamil, int trainer_Id)
	{
		
		System.out.println(" Trainer1 details information :"+name+","+dept+","+gamil+","+trainer_Id);
		System.out.println();
		for(int i=0;i<Course.length;i++)
        {
   	
       if (Course[i]==T1)
        {
       	
       
       System.out.println("Trainer1 can teach : " +Course[i]);
        }
       else if(Course[i]==T2 )
       {

           System.out.println("Trainer2 can teach : " +Course[i]); 
       }
       
   
	      
       else if(Course[i]!=T3)
		  {
    	   System.out.println("Trainer3 can teach : " +Course[i]);
		  }
		
        }
	}
}
