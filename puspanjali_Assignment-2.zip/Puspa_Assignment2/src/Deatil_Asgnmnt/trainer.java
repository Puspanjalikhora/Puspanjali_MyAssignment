package Deatil_Asgnmnt;

public class trainer 
{
	String name,department,email;
	int id; 
	
	public void trainer1(String name,String dept  ,String gamil, int trainer_id)
	{
		
		System.out.println(" Trainer1 details information :"+name+","+dept+","+gamil+","+trainer_id);
		System.out.println("Trainer1 Can teach Selenium");
	}
	public void trainer2(String name,String dept  ,String gamil, int trainer_id)
	{
     System.out.println("Trainer2 details:"+name+","+" "+dept+","+gamil+","+trainer_id);
     System.out.println("Trainer2 Can teach Web developmet");
	}
}
