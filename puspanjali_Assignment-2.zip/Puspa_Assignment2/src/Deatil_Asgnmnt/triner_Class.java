package Deatil_Asgnmnt;

public class triner_Class extends trainer

{
	//using methods 
	String name,department,email;
	int id;
	

	public static void main(String[] args)
	
	{
		triner_Class Tr= new triner_Class();
		Tr.trainer1("Mukesh", "Testing","mukesh@gmail.com" , 1);
		System.out.println();
		Tr.trainer2("Hitesh", "web development", "mukesh@gmail.com", 2);
		System.out.println();
		Tr.Trainer3("Mukesh","DevOps","mukesh@gmail.com",3);
		

	}
	
	
	
	public void Trainer3(String name,String dept  ,String gamil, int trainer_id)
	{
		
		System.out.println("Trainer3 details information :"+name+","+dept+","+gamil+","+trainer_id);
		System.out.println("Trainer3 Can teach Devops");
	}
		
	
	}



