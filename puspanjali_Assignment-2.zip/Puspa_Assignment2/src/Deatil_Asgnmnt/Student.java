package Deatil_Asgnmnt;

import java.util.Scanner;
class Students {
	String name;
	String phone;
	String email;
	String address;
	//String Status;
	// TODO Auto-generated constructor stub
}

public class Student {
	 private static Scanner sc;
	 
	
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in); 
		System.out.println("please enter the number of student ");
		 int size= Integer.parseInt(sc.nextLine());
		 //int count=5;
		 Students students[]= new Students[size];
		 for (int i=0;i<size;i++)
		   {
			 
				students[i]= new Students();
				System.out.println("please enter  your name ");
				students[i].name=sc.next();
					
				System.out.println("please enter your phnumber "); 
				
				students[i].phone= sc.next();
			
				System.out.println("please enter your email "); 
				
				students[i].email=sc.next();
				
				System.out.println("please enter your Address "); 
				students[i].address=sc.next(); 
				
				//System.out.println("please enter your status "); 
		   }
		 
			System.out.println("Please enter which student deatils you are looking for");
		 
		 //specific student details
			//System.out.println("please enter your status ");
			Scanner sc1 = new Scanner(System.in); 
			 int count= Integer.parseInt(sc1.nextLine());
				System.out.println("Stusent_Id:"+count);
				int status= count-1;
				//System.out.println("You have entire the deatils");
				System.out.println("Name:"+students[status].name);
				
				System.out.println("Phone:"+students[status].phone);
				System.out.println("Email:"+students[status].email);
				
				
				

	

}
}
