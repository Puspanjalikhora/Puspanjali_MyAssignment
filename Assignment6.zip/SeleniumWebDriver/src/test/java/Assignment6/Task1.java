package Assignment6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.manage().window().maximize();
		

            /*xpath path for userName*/		
		driver.findElement(By.xpath("//input[@placeholder='Username']"));
		driver.findElement(By.xpath("(//div[contains(@class,'bottom-space')]/div//input)[1]"));
        driver.findElement(By.xpath("(//input[contains(@class,'active')])[1]"));
        
        /*xpath path for Password*/	
        driver.findElement(By.xpath("//input[@type='password']"));
        driver.findElement(By.xpath("(//input[contains(@class,'active')])[2]"));
        driver.findElement(By.xpath("(//div[contains(@class,'bottom-space')]/div//input)[2]"));
        /*xpath path for Login*/	
		driver.findElement(By.xpath("//button[text()=' Login ']"));
		driver.findElement(By.xpath("//button[normalize-space()='Login']"));
		driver.findElement(By.xpath("//div[contains(@class,'login-action')]//button"));
		
		
		
		 /*Css Selector for userName*/	
		driver.findElement(By.cssSelector("input[placeholder='Username']"));
		driver.findElement(By.cssSelector("input[name*='username']"));
		driver.findElement(By.cssSelector("div[class*='bottom-space'] div  input[name*='username']"));
		
		 /*Css Selector for Password*/
		driver.findElement(By.cssSelector("input[type='password']"));
		driver.findElement(By.cssSelector("input[placeholder='Password']"));
		driver.findElement(By.cssSelector("div[class*='bottom-space'] div  input[name*='password']"));
		driver.findElement(By.cssSelector("input[type$='password']"));
		
		 /*Css Selector for Login*/
		driver.findElement(By.cssSelector("button[type='submit']"));
		driver.findElement(By.cssSelector("button[class*='oxd-button']"));
		driver.findElement(By.cssSelector("button[class$='login-button']"));
		
		
	}

}
