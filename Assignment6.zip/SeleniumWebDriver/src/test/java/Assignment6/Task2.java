package Assignment6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task2 {

	public static void main(String[] args) throws InterruptedException {
		 
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[text()=' Login ']")).click();
		Thread.sleep(3000);
		String text=driver.findElement(By.cssSelector("ul[class $='oxd-main-menu']")).getText();
		System.out.println("Matching Hyperlink is :" + text);
		System.out.println("********************************************");
		Thread.sleep(3000);
	     driver.findElement(By.xpath("//span[normalize-space()='Admin']")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("(//button[normalize-space()='Add'])[1]" )).click();
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("A");
	     Thread.sleep(2000);
	     String allText=driver.findElement(By.xpath("//div[@role='listbox']")).getText();
	     System.out.println("All A in employee name:"+allText );
	     driver.close();
	     
		
		
		  
		
	}

}
