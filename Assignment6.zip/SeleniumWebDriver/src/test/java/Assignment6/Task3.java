package Assignment6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task3 {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[text()=' Login ']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Admin']")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("(//button[normalize-space()='Add'])[1]" )).click();
	     Thread.sleep(2000);
	     /*X PATh for all elements under Add User section*/

	     /* xpath for Employee Name*/
	     driver.findElement(By.xpath("//input[@placeholder='Type for hints...']"));
	     driver.findElement(By.xpath("(//input[@placeholder='Type for hints...'])[1]"));
	     driver.findElement(By.xpath("//input[contains(@placeholder,'Type')]"));
	     driver.findElement(By.xpath("//div[ contains(@class,'input--active')]//input[@placeholder='Type for hints...']"));
	   
	     /*for UserName*/
	     driver.findElement(By.xpath("(//input[@autocomplete='off'])[1]"));
	     driver.findElement(By.xpath("(//input[contains(@class,'oxd-input')])[2]"));
	     driver.findElement(By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]"));
	     /*xpath for Password*/
	     driver.findElement(By.xpath("//div[contains(@class,' user-password-cell')]//div[contains(@class,'input-field')]//div//input[@type='password']"));
	     driver.findElement(By.xpath("(//input[@type='password'])[1]"));
	     driver.findElement(By.xpath("(//input[contains(@autocomplete,'off')])[2]"));
	     
	 
	     
	     /*xpath for confirm Password*/
	     driver.findElement(By.xpath("(//div[contains(@class,'oxd-grid-item')]//div[contains(@class,'bottom-space')]//div//input[@type='password'])[2]"));
	     driver.findElement(By.xpath("(//input[@type='password'])[2]"));
	     driver.findElement(By.xpath("(//input[contains(@autocomplete,'off')])[3]"));
	     
	     /*path for UserRole*/
	     driver.findElement(By.xpath("(//div[text()='-- Select --'])[1]"));
	     driver.findElement(By.xpath("(//div[contains(@class,'select-text ')])[1]"));
	     driver.findElement(By.xpath("(//div[@tabindex='0'])[1]"));
	     
	     /*xpath for Status*/
	     driver.findElement(By.xpath("(//div[@tabindex='0'])[2]"));
	     driver.findElement(By.xpath("(//div[contains(@class,'text-input')])[5]"));
	     driver.findElement(By.xpath("(//div[text()='-- Select --'])[2]"));
	}

}
