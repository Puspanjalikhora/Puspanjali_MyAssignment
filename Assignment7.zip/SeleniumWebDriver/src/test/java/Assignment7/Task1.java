package Assignment7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
	driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
	String allText	=driver.findElement(By.tagName("span")).getText();
	 WebElement userName= driver.findElement(By.name("username"));
	 WebElement passWord= driver.findElement(By.name("password"));
	 
	System.out.println("Please entire the username and password its required For Login:");
	
	 System.out.println("Username border details:"+userName.getCssValue("border"));
	 System.out.println("Password  border details:"+passWord.getCssValue("border"));
	 driver.close();



	}

}
