package Assignment7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class Task5_EdgeBrowser {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new EdgeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		
	  driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
	  Thread.sleep(3000);
	  
	  String url=driver.getCurrentUrl();
	  if(url.contains("dashboard"))
	  {
		 // driver.findElement(By.xpath("(//img[@alt='profile picture'])[1]")).click();
		 
		  driver.findElement(By.xpath("//p[contains(@class,'userdropdown')]")).click();
	    WebElement  element =driver.findElement(By.xpath("//a[text()='Logout']"));
		  Thread.sleep(1000);
		  
		  Actions act=new Actions(driver);
			act.moveToElement(element).click().perform();

	  }
	  
	  
	}

}
