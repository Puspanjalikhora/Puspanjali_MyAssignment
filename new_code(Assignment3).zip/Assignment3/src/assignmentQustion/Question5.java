package assignmentQustion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

 //Write a program which will pick the values from Array and Store them List
  public class Question5 
  {

	public static void main(String[] args)
	{
        //First Way
		String [] course= {"selenium","java","c#","c++"};
		
	List<String> myList	=Arrays.asList(course);
	System.out.println("convert the List of array values in to a List:"+ myList);
	
	//2ND way using foreachloop
	
	List<String>list= new ArrayList<>();
	
	for(String coueseName :course)
	{
		list.add(coueseName);
		
	}
	System.out.println(" 2nd way >List of array values displying in List"+ list);
				
	}

}
