package assignmentQustion;

import java.util.Arrays;
import java.util.List;

//Write a program which can store List of Integer values and print all the values using for loop
public class Question1
{

	public static void main(String[] args)
	{
		List<Integer> myList= Arrays.asList(11,98,45,28);
		
		for(int i=0;i<myList.size();i++)
		{
			System.out.println(myList.get(i));
		}
		
	}

}
