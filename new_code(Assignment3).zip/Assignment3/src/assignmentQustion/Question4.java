package assignmentQustion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Write a program which will print sum of all numbers which is stored in list.
public class Question4 
{

	public static void main(String[] args) 
	{
		List<Integer> mylist=new ArrayList<>();
		
		mylist.add(12);
		mylist.add(67);
		mylist.add(45);
		mylist.add(98);
		mylist.add(23);
		
		int sum=0;
		
        for (int i = 0; i < mylist.size(); i++)
        	sum = sum+ mylist.get(i);
 
			System.out.println("printing sum of all numbers which is stored in list:"+sum);
			
		}
		  

	

}
