package assignmentQustion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Create a list of numbers 33,44,55,66,77,88 and perform below operation
//Remove second element from list using index
//Remove second element from list using value
//Add 90 at index 3
//Get the length of list
//Print all values from list using any values
//Convert List into array.




public class Question6
{



	public static void main(String[] args)
	{
		//List<Integer> myList=Arrays.asList(33,44,55,66,77,88);
		
		 List<Integer> mentorsNumber= new ArrayList<>();
		 
		 mentorsNumber.add(33);
		 mentorsNumber.add(44);
		 mentorsNumber.add(55);
		 mentorsNumber.add(66);
		 mentorsNumber.add(77);
		 mentorsNumber.add(88);
		 
		 
		System.out.println("List of the element before remove:"+mentorsNumber);
		
		//1> Remove second element from list using index
		System.out.println("After removed index 2 value from list:"+mentorsNumber.remove(2));
		System.out.println(mentorsNumber);
		
		//2>Remove second element from list using value
		
		System.out.println(mentorsNumber.remove( Integer.valueOf(66)));
		System.out.println(mentorsNumber);
		
		//Add 90 at index 3
		   mentorsNumber.add(3, 90);
			System.out.println("Add vaue at 3rd index :"+mentorsNumber);
		
		//4> Get the length of list
		System.out.println("Length of the List:"+" "+mentorsNumber.size());
		
		
		//5>Convert List into array.
		Integer[] intarray= new Integer[mentorsNumber.size()];
		//Convert List into array using toArray methods 
		mentorsNumber.toArray(intarray);
		
		for(int i=0;i<mentorsNumber.size();i++)
		{
			System.out.println(intarray[i]);
		}
		
		for(Integer value :intarray)
		{
			System.out.println("Convert List into array:"+value);
		}
				
		
	}
	
}
