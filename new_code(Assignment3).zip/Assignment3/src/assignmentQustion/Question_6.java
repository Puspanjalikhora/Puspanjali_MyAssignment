package assignmentQustion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Question_6 {

	public static void main(String[] args) 
	{
  // List<Integer> myList=Arrays.asList(33,44,55,66,77,88);
   List<String> mentorsName= new ArrayList<>();
   mentorsName.add("Anjali");
   mentorsName.add("Bina");
   mentorsName.add("Parasar");
   mentorsName.add("Mina");
   mentorsName.add("puspa");
	System.out.println(mentorsName);
     System.out.println(mentorsName.remove(2));
		System.out.println(mentorsName);
	}
		
	}


