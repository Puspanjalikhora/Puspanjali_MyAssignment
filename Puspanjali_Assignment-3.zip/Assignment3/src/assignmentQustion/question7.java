package assignmentQustion;

import java.util.Arrays;
import java.util.List;

// Web Automation, API Automation, Mobile Automation
public class question7
{

	public static void main(String[] args)
	{
		
		List<String> automationTool=Arrays.asList("Web Automation", "API Automation", "Mobile Automation");
		
		for(String names:automationTool)
		{
			if(names.contains("Mobile"))
			{
				System.out.println("True");
			}
			
			    
	    }

     }
}
