package assignmentQustion;

import java.util.Arrays;
import java.util.List;

public class question2 {

	public static void main(String[] args) 
	{
		List<String> myList=Arrays.asList("Anjali","Puspanjali","Mukesh","Jeevan","Akash");
		
		//Using for loop to access all the value which is stored in to the list
		
		for(int i=0;i<myList.size();i++)
		{
			System.out.println("List of value:" +" " +myList.get(i));
		}
	}

}
