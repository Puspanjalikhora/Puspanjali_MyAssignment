package assignmentQustion;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;



//Write a program which can store List of Integer values and print all the values using for iterator
public class Question3 
{

	public static void main(String[] args) 
	{
		List<Integer>  myList= Arrays.asList(14,67,78,98);
		Iterator<Integer> itr =myList.iterator();
		
		while(itr.hasNext())
		{
			int number=itr.next();
			System.out.println("list of value:"+ number);
		}
		
	 
	}

}
