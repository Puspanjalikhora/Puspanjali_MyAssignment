package Classobject;

public class Cal_example
{
	public static void main(String args[])
	{
		Cal_example obj1= new Cal_example();
		obj1.Sum(10,20);
		obj1.Sub(30, 10);
		obj1.Mul(10,30);
		obj1.Div(30, 5);
		
	}
	public void Sum(int a, int b) 
	
	{
		int result =a+b;
	   System.out.println("sum of two number is:"+ result);
	}
   public void Sub(int a, int b) 
	
	{
		int result =a-b;
		System.out.println("sub of two number is:"+ result);
	}
   
   
   public void Mul(int a, int b) 
	
	{
		int result =a*b;
		System.out.println("Mul of two number is:"+ result);
	}
   
   public void Div(int a, int b) 
	
	{
		int result =a/b;
	System.out.println("sub of two number is:"+ result);
	}
}
