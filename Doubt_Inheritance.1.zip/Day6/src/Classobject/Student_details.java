package Classobject;
import java.util.Scanner;

public class Student_details 
{
	
		String name;
		String email;
		String stu_id;
		String Phone;
		String address;
		String status;
		int score;
		
		public Student_details() 
		{
			this(" ", " "," "," ", " "," ",0);
		}
		public Student_details(String initName,  String s_email,String initId,String s_Phone, String s_address, String t_status,int initScore)
		{
			name = initName;
			email=s_email;
			stu_id = initId;
			Phone=s_Phone;
			address=s_address;
			status  =t_status;
			score = initScore;
		}
	}

 class Teacher 
  {	 
  	public static void main(String[] args)
  	{
  		
  		
  		 Scanner in = new Scanner(System.in);
			System.out.println("Input number of students:");
			int n = Integer.parseInt(in.nextLine().trim());
			System.out.println("Input Student Name, ID, Score:");
			Student_details stu = new Student_details();
			Student_details max = new Student_details();
			Student_details min = new Student_details(" ", " "," "," "," "," ", 100);
			for (int i = 0; i < n; i ++) 
			{
				stu.name = in.next();
				stu.email=in.next();
				stu.Phone=in.next();
				stu.address=in.next();
				stu.status=in.next();
				stu.stu_id = in.next();
				stu.score = in.nextInt();
				if (max.score < stu.score) 
				{
					max.name = stu.name;
					max.stu_id = stu.stu_id;
					max.score = stu.score;
				}
				if (min.score > stu.score)
				{
					min.name = stu.name;
					min.stu_id = stu.stu_id;
					min.score = stu.score;
				}
			}
			System.out.println("name, ID of the highest score and the lowest score:");
			System.out.println(max.name + " " + max.stu_id);
			System.out.println(min.name + " " + min.stu_id);
			in.close();
  		
  		
  	}
 }
	    	

