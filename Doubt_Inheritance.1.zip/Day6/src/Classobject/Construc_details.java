package Classobject;

public class Construc_details {
	
	String name;
	int EmpId;

	public static void main(String[] args)
	
	{
		Construc_details anjali= new Construc_details("puspanjali",1001);
		 
		 
		Construc_details obj1= new Construc_details("Bikas",1002);
		Construc_details obj2= new Construc_details("Sonali",1005);
		
		System.out.println("**************");
		anjali.Emp_Login();
		anjali.EmployeeInformation_Details();
		obj1.EmployeeInformation_Details();
		obj2.EmployeeInformation_Details();
       
        anjali.Emp_Logout();
	}
	
	public Construc_details(String empname, int employeeid)
	{
		name=empname;
		EmpId=employeeid;
	}
	
	public void EmployeeInformation_Details()
	{
		System.out.println("Employee Name is "+ name);
		System.out.println("Employee id is:"+EmpId);
	}
	public void Emp_Login()
	{
		System.out.println("Employee has log in");
	}
	public void Emp_Logout()
	{
		System.out.println("Employee has logout");
	}

}
