	package Classobject;

import java.util.Scanner;

public class Construc_overloading 
{
   
	public Construc_overloading()
	{
	 System.out.println("i am in 1st constructor");	
	}
	
	public Construc_overloading(String emp_Name, int emp_Id, long phone_Number)
	{
		System.out.println("Employee details are: "+emp_Name+""+emp_Id+""+phone_Number);
	}
	
	public Construc_overloading(String emp_Name,int emp_Id)
	{
		System.out.println("Employee details are:"+emp_Name+" "+emp_Id);
	}
	
	
	public Construc_overloading(int emp_Id,String emp_Name)
	{
		System.out.println("Employee details are:"+emp_Id+" "+emp_Name);
	}
	
	
	
	
	
	public static void main(String[] args) 
	
	{
    	Construc_overloading sc= new Construc_overloading();
    	System.out.println();
    	Construc_overloading sc1= new Construc_overloading("Anjali",1,99587809);
    	System.out.println();
    	Construc_overloading sc2= new Construc_overloading("Anjali",3);
    	System.out.println();
    	
     	Construc_overloading sc3= new Construc_overloading( 3,"Anjali");

    	
      

	}
}
