package Classobject;

public class calc3_result {

	public static void main(String[] args)
	{
		
		
			Calc2 obj= new Calc2();
		double Sum=	obj.sum(20, 10.5);
		float Sub=	obj.sub(50, 10f);
		int mul=obj.mul(5,20);
		int div=obj.div(30, 2);
	 //  String name=  obj.Getname("anjali", "kumari");
		System.out.println("Sum is sum:"+ Sum);
		System.out.println("Sub is Sub:"+ Sub);
		System.out.println("div is sum:"+ div);
		System.out.println("mul is sum:"+ mul);
		// System.out.println("your name is:"+ name);
	  
		}
		
		public String Getname(String First_name, String Last_name)
		{
			String result=First_name+""+Last_name;
			return result ;
			  
			   
		}
		
		public double sum(int n1, double n2)
		{
			double result=n1+n2;
			return result;
		}
		public float sub(int n1, float n2)
		{
			float result=n1+n2;
			return result;
		}
		public int mul(int n1, int n2)
		{
			int result=n1+n2;
			return result;
		}
		public int div(int n1, int n2)
		{
			int result=n1/n2;
			return result;
		}

	}


