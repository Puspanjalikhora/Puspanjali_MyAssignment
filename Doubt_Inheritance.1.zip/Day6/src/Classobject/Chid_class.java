package Classobject;

import aasign.Inheritance_Concept;

public class Chid_class extends Inheritance_Concept
{

	public static void main(String[] args)
	{
		Chid_class obj= new Chid_class ();
		obj.display();
		obj.show();
		obj.Add();
		obj.sub();
		
	}
	
	public void Add()
	{
		System.out.println("child method called as Add method");
	}
	public void sub()
	{
		System.out.println("child method called as sub method");
	}

}
