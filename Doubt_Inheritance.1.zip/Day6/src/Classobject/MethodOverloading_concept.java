package Classobject;

public class MethodOverloading_concept {

	public static void main(String[] args) 
	{
		MethodOverloading_concept obj= new MethodOverloading_concept();
		obj.add(50.20d, 11.02f);
		double value =obj.add(10.02, 0.5);
		System.out.println("result is:"+value);
		obj.add(50.20d, 11L);
		obj.add("anjali", 1994);
	}
	
	
	public void add()
	{
		System.out.println("I am in add method");
	}
  
	public void add(int x,int y)
	{
		int result=x+y;
		System.out.println("result is:"+result);
	}
	public double add(double x,double y)
	{
		double result=x+y;
		return result;
	}
	
	public void add(double x,int y)
	{
		double result=x+y;
		System.out.println("reslut is:"+ result);
	}
	public void add(double x, float y)
	{
		double result = x+y;
		System.out.println("reslut is:"+ result);
		
	}
	public void add(double x, long y)
	{
		double result = x+y;
		System.out.println("reslut is:"+ result);
		
	}
	public void add(String x, int y)
	{
		String result = x+y;
		System.out.println("reslut is:"+ result);
		
	}
	
}
