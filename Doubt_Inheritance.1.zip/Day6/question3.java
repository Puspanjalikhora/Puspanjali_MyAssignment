package aasign;

import java.util.Scanner;

public class question3 
{
	//name, email, phone, address, status
	String name;
	String email;
	String address;
	long  phone;
	int stu_id;
	boolean status;
	 	
		
			public question3() 
			{
				this(" ", " ", 0);
			}
			public question3(String initName, String s_email,String s_address,int initId, long Sphone,boolean S_status) 
			{
				name = initName;
				email=s_email;
				address=s_address;
				stu_id = initId;
				phone= Sphone;
				status = S_status;
			}
		

	
			public static void main(String[] args) {
				{
					
				
				Scanner in = new Scanner(System.in);
				System.out.println("please entire the  number of students:");
				int n = Integer.parseInt(in.nextLine().trim());
				System.out.println("entire  Student Name, email, address, id,phone number, status :");
				Student stu = new Student();
				
				Student max = new Student();
				Student min = new Student(" ", " ", 100);
				for (int i = 0; i < n; i ++) 
				   {
					stu.name = in.next();
					
					stu.stu_id = in.next();
					
					stu.score = in.nextInt();
					if (max.score < stu.score) {
						max.name = stu.name;
						max.stu_id = stu.stu_id;
						max.score = stu.score;
					}
					if (min.score > stu.score) {
						min.name = stu.name;
						min.stu_id = stu.stu_id;
						min.score = stu.score;
					}
				}
				System.out.println("name, ID of the highest score and the lowest score:");
				System.out.println(max.name + " " + max.stu_id);
				System.out.println(min.name + " " + min.stu_id);
				in.close();
			}
			}
}

