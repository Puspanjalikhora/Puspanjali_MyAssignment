package Assignment10;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Ineuron_Assignment {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://ineuron-courses.vercel.app/login");
		driver.manage().window().maximize();
	    Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("ineuron@ineuron.ai");
	
		
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("ineuron");
		
		driver.findElement(By.xpath("//button[text()='Sign in']")).click();
		
		Thread.sleep(2000);
		WebElement element=	driver.findElement(By.xpath("//span[text()='Manage']"));
        
         
		Actions act=new Actions(driver);
		act.moveToElement(element).click().perform();
		 Thread.sleep(2000);
		//driver.findElement(By.xpath("//h1[text()='Manage Courses']")).click();
		 act.moveToElement(driver.findElement(By.xpath("//h1[text()='Manage Courses']"))).build().perform();
		Thread.sleep(2000);
		String course="SeleniumTesting";
        driver.findElement(By.xpath("//button[text()='Add New Course ']")).click();
        driver.findElement(By.xpath("//input[@type='file']")).sendKeys("C:\\Users\\dell\\Downloads\\book.JPG");
        driver.findElement(By.id("name")).sendKeys(course);
		driver.findElement(By.id("description")).sendKeys("Testing for adding new course");
		driver.findElement(By.id("instructorNameId")).sendKeys("Mukesh");
		driver.findElement(By.id("price")).sendKeys("5000");
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,550)", "");
		
		driver.findElement(By.name("startDate")).click();
		driver.findElement(By.xpath("//button[@aria-label='Next Month']")).click();
		
		driver.findElement(By.xpath("//div[text()='22']")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("endDate")).click();
		driver.findElement(By.xpath("//button[@aria-label='Next Month']")).click();
		driver.findElement(By.xpath("//div[text()='26']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()='Select Category']")).click();
		driver.findElement(By.xpath("//button[text()='Mukesh']")).click();
		driver.findElement(By.xpath("//button[text()='Save']")).click();
		int count=0;
		Thread.sleep(5000);
		List<WebElement> ele=driver.findElements(By.xpath("//*[td]"));
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollBy(0,500)");
		
		
		for(WebElement el:ele) 
		{
			count++;
			if(el.getText().contains(course)) 
			{

				driver.findElement(By.xpath("(//button[text()='Delete'])["+count+"]")).click();
				System.out.println("course deleted");
				break;
			}
			else 
			{
				System.out.println("Course not deleted" +el.getText());
			}
		}
		
		Thread.sleep(2000);
	  driver.findElement(By.xpath("//button[text()='Sign out']")).click();

	}

}
