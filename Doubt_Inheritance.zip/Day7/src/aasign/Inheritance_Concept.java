package aasign;

public class Inheritance_Concept 
{

	public static void main(String[] args)
	{
		
	}
	
	public void show()
	{
		System.out.println("Parent class called show method");
	}
	public void display()
	{
		System.out.println("parent class called display method");
	}

}
