package Assignment8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Task4 {

	public static void main(String[] args) throws InterruptedException 
	{
	  
		WebDriver driver = new ChromeDriver();
	  driver.get("https://www.facebook.com/");
	  driver.manage().window().maximize();
	  driver.findElement(By.linkText("Create New Account")).click();
	  Thread.sleep(2000);
	  
	  driver.findElement(By.cssSelector("input[name$='firstname']")).sendKeys("Anjali");
	  
	  driver.findElement(By.cssSelector("input[name$='lastname']")).sendKeys("Kumari");
	 
	  driver.findElement(By.cssSelector("input[name*='reg_email__']")).sendKeys("9938302746");
		
	  driver.findElement(By.cssSelector("input[name*='reg_passwd__']")).sendKeys("Pass@word2");
	  
	  
	   Select day=new Select(driver.findElement(By.cssSelector("select[id$='day']")));

		Select month=new Select(driver.findElement(By.cssSelector("#month")));
	  
	  
		Select year= new Select(driver.findElement(By.cssSelector("#year")));
		
		day.selectByValue("10");
		Thread.sleep(2000);
		month.selectByVisibleText("Aug");
		Thread.sleep(2000);
		//monthYear.selectByVisibleText("2020");
		year.selectByValue("1997");
		
          //List<WebElement> allradioBtn  =driver.findElements(By.cssSelector("span[data-type$='radio']"));
		List<WebElement> allradioBtn=driver.findElements(By.cssSelector("span[data-name*='gender_wrapper']"));
           int val  =allradioBtn.size();
       
       for(WebElement ele : allradioBtn) 
       {
    	   if(ele.getText().contains("Female"))
    	   {
    		   ele.click();
    		   break;
    	   }
    	   
       }
       
		 
		Thread.sleep(2000);
		
		List<WebElement> alltext =driver.findElements(By.cssSelector("button[name$='submit']"));
		
		 for(WebElement ele : alltext) 
	       {
	    	   if(ele.getText().equals("Sign Up"))
	    	   {
	    		   ele.click();
	    		   
	    	   }
	    	   
	       }
	
	     
	}

}
