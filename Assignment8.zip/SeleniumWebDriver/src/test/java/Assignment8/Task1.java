package Assignment8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Task1 {

	public static void main(String[] args) 
	{
		WebDriver driver = new EdgeDriver();
		  driver.get("https://www.facebook.com/");
		  driver.manage().window().maximize();
		  //Task1
		 String Text =driver.findElement(By.xpath("//h2[contains(text(),'Facebook helps you connect and share with the peop')]")).getText();
		 System.out.println(Text);

		driver.close();
		
	}
     
   }
