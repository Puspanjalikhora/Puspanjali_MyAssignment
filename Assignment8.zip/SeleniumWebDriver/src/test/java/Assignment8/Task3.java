package Assignment8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;

public class Task3 {

	public static void main(String[] args) throws InterruptedException 
	{
	  
		WebDriver driver = new ChromeDriver();
	  driver.get("https://www.facebook.com/");
	  driver.manage().window().maximize();
	  
	  driver.findElement(By.xpath("//a[text()='Create New Account']")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//input[@aria-label='First name']")).sendKeys("Anjali");
	  driver.findElement(By.xpath("//input[@aria-label='Surname']")).sendKeys("Kumari");
	 
	  driver.findElement(By.xpath("//input [@aria-label='Mobile number or email address']")).sendKeys("9938302746");
		
	  driver.findElement(By.xpath("//input[@autocomplete='new-password']")).sendKeys("Pass@word2");
	  
	 
	  // WebElement monthDropdown = driver.findElement(By.xpath("//select[@aria-label='Day']"));
	   Select month1=new Select(driver.findElement(By.xpath("//select[@aria-label='Day']")));

		Select month=new Select(driver.findElement(By.xpath("//select[@title='Month']")));
	  
	  
		Select monthYear= new Select(driver.findElement(By.xpath("//select[@aria-label='Year']")));
		
		month1.selectByValue("10");
		Thread.sleep(2000);
		month.selectByVisibleText("Aug");
		Thread.sleep(2000);
		//monthYear.selectByVisibleText("2020");
		monthYear.selectByValue("1997");
		 driver.findElement(By.xpath("//label[text()='Female']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[text()='Sign Up'])[1]")).click();
	
   
	}

}
