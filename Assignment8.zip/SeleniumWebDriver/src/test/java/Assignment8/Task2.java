package Assignment8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Task2 {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver = new EdgeDriver();
		  driver.get("https://www.facebook.com/");
		  driver.manage().window().maximize();
		 
		 List<WebElement> allLinks= driver.findElements(By.xpath("//div[@id='pageFooterChildren']//li/a[@href]"));
		// List<WebElement> allLinks= driver.findElements(By.xpath("//a[@href]"));
			
			for(WebElement ele:allLinks)
			{
				System.out.println("All Link text are:"+ ele.getText());
	
			String allText =ele.getText();
			
			if(allText.contains("Create Page"))
			{
				System.out.println("Create Page Link is present");
				ele.click();
				break;
			}
	   }
		
		Thread.sleep(2000);	
	driver.close();
   }
}
