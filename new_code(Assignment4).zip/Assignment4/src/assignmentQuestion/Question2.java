package assignmentQuestion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Write a program which will accept List of String and produce another List of string of which 
//will have only values which starts with git
//Input – Git, Github, GitLab,GitBash, Selenium, Java, Maven
//Output- Git, Github, Gitlab, GitBash

public class Question2 
{

	public static void main(String[] args)
	{
		
		
		ArrayList<String> list= new ArrayList<String>();
		 
		 list.add("Selenium");
		 list.add("Java");
		 list.add("Maven");
		  list.add("Git");
		 list.add("GitHub");
		 list.add("GitLab");
		 list.add("GitBash");
		
		
	  
           for(String myList:list)
		    {
		   
		    	//boolean str= list.contains("Git");
		    	
		    	if(myList.startsWith("Git"))
		    	{
		    		System.out.println(myList);
		    	}
		    	
		    	
		    	
		    }
		    
		    
	       
	}
}


