package assignmentQuestion;

//Create a list which can accept another list as an element.
//List 1- 11,22,33
//List 2-  9,19,29	
//List 3-  7,17,27

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Question5
{

	public static void main(String[] args) 
	{
		
         //Quick way to create list of Integer Value
		List<Integer> list1= Arrays.asList(11,22,33);
		
		ArrayList<Integer> list2= new ArrayList<>(Arrays.asList(9,19,29));
		
		List<Integer> list3= new ArrayList<>(Arrays.asList(7,17,27));
		
		List<Integer> mylist= new ArrayList<>();
		mylist.addAll(list1);
		mylist.addAll(list2);
		mylist.addAll(list3);
		System.out.println(mylist);
		
	//	2nd way OR
		
		ArrayList<Integer> myList1= new ArrayList<Integer>();
		myList1.add(11);
		myList1.add(22);
		myList1.add(33);
		ArrayList<Integer> myList2= new ArrayList<Integer>(myList1);
		
		myList2.add(9);
		myList2.add(19);
		myList2.add(29);
		ArrayList<Integer> myList3= new ArrayList<Integer>(myList2);
		
		myList3.add(7);
		myList3.add(17);
		myList3.add(27);
		System.out.println("Second way  accept another list as an element");
		System.out.println(myList3);

	}

}
